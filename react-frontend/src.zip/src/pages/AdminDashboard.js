import React from 'react';

const AdminDashboard = () => <h1>Admin Dashboard</h1>;

export default AdminDashboard;
